document.addEventListener("DOMContentLoaded", function() {
  // Simular datos de clases
  const clases = [
    { nombre: "Clases de Afrofit Boxing", horario: "Lunes y Miércoles 19:00 - 20:00" },
    { nombre: "Clases de Afrofit Boxing", horario: "Martes y Jueves 18:00 - 19:00" },
  ];

  const clasesList = document.getElementById("clases-list");

  // Renderizar las clases
  clases.forEach(clase => {
    const claseItem = document.createElement("li");
    claseItem.classList.add("clase-item");
    claseItem.innerHTML = `
      <h3>${clase.nombre}</h3>
      <p>${clase.horario}</p>
    `;
    clasesList.appendChild(claseItem);
  });

  // Manejar la reserva de saco de boxeo
  const reservaForm = document.getElementById("reserva-form");
  reservaForm.addEventListener("submit", function(event) {
    event.preventDefault();
    const fecha = document.getElementById("fecha").value;
    const hora = document.getElementById("hora").value;
    // Aquí puedes implementar la lógica para manejar la reserva
    console.log("Reserva realizada para", fecha, "a las", hora);
    alert("Reserva realizada correctamente");
    // Puedes enviar los datos al servidor para manejar la reserva
  });

  // Manejar el proceso de pago
  const pagoForm = document.getElementById("pago-form");
  pagoForm.addEventListener("submit", function(event) {
    event.preventDefault();
    // Aquí puedes implementar la lógica para manejar el pago
    // Puedes utilizar una pasarela de pago como Stripe, PayPal, etc.
    console.log("Proceso de pago completado");
    alert("Pago realizado correctamente");
    // Puedes enviar los datos al servidor para procesar el pago
  });

  const registroForm = document.getElementById("registro-form");
  
  registroForm.addEventListener("submit", function(event) {
    event.preventDefault();
    
    const email = document.getElementById("email").value;
    const telefono = document.getElementById("telefono").value;
    const contraseña = document.getElementById("contraseña").value;
    
    // Aquí puedes implementar la lógica para manejar el registro
    console.log("Registro exitoso");
    alert("Registro exitoso");
    // Puedes enviar los datos al servidor para manejar el registro
  });
});
